===========================================================================
Primary purpose         : Single+Coop play / Deathmatch
===========================================================================
Title                   : Dave1.WAD
Filename                : DAVE1.WAD
Release date            : 15.05.1994 (Timestamp of WAD- and textfile)
Author                  : David Bruni
Email Address           : 74353,357
                          dbruni@houston.rr.com
Homepage                : http://home.houston.rr.com/dbruni/
Other Files By Author   : dave.wad, omen.wad, The Hunger level
                          (among others)
Misc. Author Info       : My second WAD file, big improvement over my
                          first attempt.

Description             : Big level with lots of special lighting and a few
                          other special effects. You have to watch your
                          back in this one. Also, lots of area left to add
                          to if you have DoomED-The Real Thing editor.
                          Availible in the Gamer's Forum as DMREAL.ZIP. I'd
                          highly recommend this editor.

Additional Credits to   : id, for making DOOM and Geoff Allan for making
                          DoomED-The Real Thing Editor. Also special
                          thanks to my wife for helping beta test this
                          floor and watching the kids so I could spend the
                          better part of a Saturday making this floor.
===========================================================================
* What is included *

New levels              : 1
Sounds                  : No
Music                   : No
Graphics                : No
Dehacked/BEX Patch      : No
Demos                   : No
Other                   : No
Other files required    : No


* Play Information *

Game                    : DOOM
Map #                   : E1M1
Single Player           : Designed for
Cooperative 2-4 Player  : Designed for
Deathmatch 2-4 Player   : Designed for
Other game styles       : No
Difficulty Settings     : Not implemented


* Construction *

Base                    : New from scratch
Build Time              : about 25 hours
Editor(s) used          : DoomEd-The Real Thing
Known Bugs              : a few misaligned wall textures, but not to
                          noticeable.


* Copyright / Permissions *

Authors MAY use this level as a base to build additional
levels provide you credit me with creating the original level and
that you say the level you've made is a modified version of my
original level.

You MAY distribute this WAD, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file
intact.


* Where to get the file that this text file describes *

The Usual: ftp://archives.3dgamers.com/pub/idgames//levels/doom/d-f/dave1.zip
and mirrors:
Sunet (Sweden) - ftp://ftp.sunet.se/pub/pc/games/idgames/
or http://ftp.sunet.se/pub/pc/games/idgames/
PlanetMirror (Australia) - http://ftp.planetmirror.com/pub/idgames/
NTUA (Greece) - ftp://ftp.ntua.gr/pub/vendors/idgames/
Gamers.org - http://www.gamers.org/pub/idgames/
ftp://ftp.fu-berlin.de/pc/msdos/games/idgames/idgames/
http://ftp.au.xemacs.org/pub/idgames/
ftp://ftp.au.xemacs.org/pub/idgames/
http://mrtg.planetmirror.com/pub/idgames/
http://www.au.horde.org/pub/idgames/



===========================================================================
Submitted to the /idgames-ftp-archives by FunDuke --> funduke@hotmail.com