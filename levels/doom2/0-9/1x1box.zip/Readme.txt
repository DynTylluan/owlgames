===========================================================================
Archive Maintainer      : Same directory as Wow???
Advanced engine needed  : None
Primary purpose         : Single play
===========================================================================
Title                   : The Worst Level Ever Made
Filename                : 1x1Box.wad
Release date            : April 26, 2012
Author                  : Doomguy 2000
Email Address           : doomguy2000@hotmail.com
Other Files By Author   : Hellish, Doomguy's Warzone, Doomguy's Warzone
                          Gold Edition, Reckless Chaos, 30,000 Levels, and
                          Doomguy's Warzone (2012).
Misc. Author Info       : The One man show behind the legendary Doomguy's
                          Warzone and 30,000 Levels.

Description             : This is my attempt to make something worse than
                          Wow.wad.  There is simply no gameplay to be found
                          here.  You are also stuck and are unable to move
                          which means you can's do anything.

===========================================================================
* What is included *

New levels              : 1
Sounds                  : No
Music                   : No
Graphics                : No
Dehacked/BEX Patch      : No
Demos                   : No
Other                   : No
Other files required    : None


* Play Information *

Game                    : Doom 2
Map #                   : Map01
Single Player           : Designed for
Cooperative 2-4 Player  : No
Deathmatch 2-4 Player   : No
Other game styles       : None
Difficulty Settings     : Not implemented


* Construction *

Base                    : New from scratch
Build Time              : 1 minute
Editor(s) used          : Doombuilder
Known Bugs              : None


* Copyright / Permissions *

Authors MAY use the contents of this file as a base for modification or
reuse.  Permissions have been obtained from original authors for any of
their resources modified or included in this file.

You MAY distribute this file, provided you include this text file, with no
modifications.  You may distribute this file in any electronic format (BBS,
Diskette, CD, etc) as long as you include this file intact.  I have
received permission from the original authors of any modified or included
content in this file to allow further distribution.

* Where to get the file that this text file describes *

The Usual: ftp://archives.3dgamers.com/pub/idgames/ and mirrors
Web sites: http://www.doomguy2000.com/downloads.html
