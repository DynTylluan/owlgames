I Joel Huenink and any other contributor to All_Hell will not be held 
reponsible for any damage to your system, loss of data, loss of sleep, employment, sanity and any other side effects that may occur by playing
All_Hell. With that said and out of the way, have fun! All_Hell is freeware, and may be distributed in its original format, including all the text forms, to any owner of registered doom2(tm). Do not contact Id software for tech support, but you may contact me at jh32322@ltec.net.
I will try to help.

Joel Huenink