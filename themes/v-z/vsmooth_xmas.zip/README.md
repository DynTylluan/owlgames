===========================================================================
Primary purpose         : Single play
===========================================================================
Title                   : SmoothDoom-Vanilla XMas-Patch
Filename                : vsmooth_xmas.wad
Author                  : Per Kristian Risvik; Simon Howard; act
Email Address           : poopsqueezenuts6969@gmail.com
			   (pls no make fun of my email name, it's for non-
			   professional stuff.)

Description             : This is a Christmas-themed patch of Simon
			   Howard's port of Kristan Risvik's SmoothDoom
			   patch for Doom.
===========================================================================
* Changes From Simon Howard's Original File *
The graphics within the .WAD labled SHTGA0, PKSG-0, SHTF-0, PKS2-0, CHGGA0,
PKCG-0, and PLSF-0 have been replaced to become more Christmas-themed. The
design for the Shotgun and Supershotgun were based on the sprites found
within "doomxmas.wad", a Christmas-themed compilation of textures, sprites,
and music files compiled by user "Doomkid". The included text file has an
exhaustive list of credits for everyone involved, including the developers
of the Christmas-themed sprites. You can find it at
https://www.moddb.com/mods/doom-christmas-for-doom-ii-final-doom. The
sprites for the Plasma Gun and Chaingun were originally designed by me, act.
The .WAD is also the source for the sprites labled PLSS-0, PLSE-0, MISL-0,
CLIPA0, AMMOA0, SHELA0, SBOXA0, ROCKA0, BROKA0, CELLA0, CELPA0, SHOTA0,
SGN2A0, LAUNA0, PLASA0, and BFUGA0. I've taken MGUNA0 from the .WAD as well,
but edited it to reflect the changes I've made to the weapon sprites seen
in the player's HUD.

* Setup instructions *

Most source ports will just load the WAD automatically, eg.

  prboom -file vsmooth.wad

For Chocolate Doom you'll need to provide different parameters:

  chocolate-doom -merge vsmooth.wad -dehlump

To play this with vanilla DOS Doom, first install Dehacked and DeuSF, which
can be found at these paths in the idgames archive:

  utils/exe_edit/dhe31.zip
  utils/graphics_edit/deutex/deutex36.zip

Then run the included batch file vsmooth.bat to install (your IWAD file will
be modified). To restore your old IWAD file, run xvsmooth.bat.

* Philosophy *

Unlike other versions of the smooth weapons mod, this version has been put
together around a deliberately conservative philosophy. Specifically:

* Vanilla demo sync is preserved, and this has been tested using statcheck
  across hundreds of demos to confirm that no desync is introduced.
* Any unnecessary changes have been avoided. For example, other versions of
  the smooth weapons mod switch the hand holding the pistol, or change the
  fist to be a gloved hand. While some changes are unavoidable, this tries
  hard to be just a smoother animated version of the original sprites.
* Sprite offsets should match the slightly-adjusted offsets from the Doom 2
  Minor Sprite Fixing Project.

* What is included *

New levels              : None
Sounds                  : No
Music                   : No
Graphics                : Replacement weapon sprites
Dehacked/BEX Patch      : Yes
Demos                   : No
Other                   : No
Other files required    : dhe31.zip, deutex36.zip for vanilla play


* Play Information *

Game                    : Doom, Doom 2
Single Player           : Designed for
Cooperative 2-4 Player  : Designed for
Deathmatch 2-4 Player   : Designed for
Other game styles       : None
Difficulty Settings     : Not applicable


* Construction *

Base                    : Derived from ZDoom version of Per Kristian's smooth
                          weapons mod
May Not Run With        : Unknown
Tested With             : DOS Doom, Chocolate Doom, PrBoom, ZDoom


* Copyright / Permissions *

This work is licensed under the Creative Commons Attribution 4.0
International License. To view a copy of this license, visit
http://creativecommons.org/licenses/by/4.0/

You are free to copy and redistribute the material in any medium or format;
and remix, transform, and build upon the material for any purpose, even
commercially. If you do so, you must give appropriate credit, provide a link
to the license, and indicate if changes were made. You may do so in any
reasonable manner, but not in any way that suggests the licensor endorses you
or your use.

* Where to get the file that this text file describes *

For the XMas Patch: https://moddb.com/mods/sdvchristmaswad/
For the original: ftp://archives.gamers.org/pub/idgames/ and mirrors
