Feel free to use this HUD as you wish, Make sure you give me credit 
if you do plan to use it. Anyways enjoy and have fun! -ZNukem